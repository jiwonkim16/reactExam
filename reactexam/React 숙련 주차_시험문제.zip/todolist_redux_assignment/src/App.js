import React from "react";
import Router from "./shared/Router";

const App = () => {
  return <Router />;
};

export default App;
